package com.example.bank.constants;

public enum ACTION {
    DEPOSIT,
    WITHDRAW
}
